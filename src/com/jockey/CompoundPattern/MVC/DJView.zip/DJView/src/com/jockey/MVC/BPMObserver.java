package com.jockey.MVC;

public interface BPMObserver {
	void updateBPM();
}
