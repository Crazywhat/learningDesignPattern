package com.jockey.MVC;

public interface BeatObserver {
	void updateBeat();
}
